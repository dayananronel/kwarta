package com.kwarta.ph.model;

public class AuctionersItem {

    private String auctioneer_image;
    private String auctioneer_amount_desc;
    private String auctioneer_amount_value;
    private String auctioneer_amount_bids;
    private String auctioneer_amount_duration;
    private String auctioneer_history_status;

    public String getAuctioneer_history_status() {
        return auctioneer_history_status;
    }

    public void setAuctioneer_history_status(String auctioneer_history_status) {
        this.auctioneer_history_status = auctioneer_history_status;
    }

    public String getAuctioneer_image() {
        return auctioneer_image;
    }

    public void setAuctioneer_image(String auctioneer_image) {
        this.auctioneer_image = auctioneer_image;
    }

    public String getAuctioneer_amount_desc() {
        return auctioneer_amount_desc;
    }

    public void setAuctioneer_amount_desc(String auctioneer_amount_desc) {
        this.auctioneer_amount_desc = auctioneer_amount_desc;
    }

    public String getAuctioneer_amount_value() {
        return auctioneer_amount_value;
    }

    public void setAuctioneer_amount_value(String auctioneer_amount_value) {
        this.auctioneer_amount_value = auctioneer_amount_value;
    }

    public String getAuctioneer_amount_bids() {
        return auctioneer_amount_bids;
    }

    public void setAuctioneer_amount_bids(String auctioneer_amount_bids) {
        this.auctioneer_amount_bids = auctioneer_amount_bids;
    }

    public String getAuctioneer_amount_duration() {
        return auctioneer_amount_duration;
    }

    public void setAuctioneer_amount_duration(String auctioneer_amount_duration) {
        this.auctioneer_amount_duration = auctioneer_amount_duration;
    }
}
